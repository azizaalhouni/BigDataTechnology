package cs523.finalProject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.*;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.json.JSONArray;

import scala.Tuple2;


public class Main {
	private static List<Record> records = new ArrayList<>();

	public static void main(String[] args) throws Exception
	{
		
		SparkConf sparkConf = new SparkConf().setAppName("Final Project").setMaster("local");
				
		JavaStreamingContext ssc = new JavaStreamingContext(sparkConf, Durations.seconds(13));
	
		String url = "https://data.seattle.gov/resource/fire-911.json?$$app_token=83GHgAaXwrGXR2mx8it9JiGDw&$where=datetime>='2021-05-10'";
		//
		JavaDStream<String> dstream = ssc.receiverStream(new JavaCustomReceiver(url.trim()));
		//Return a new DStream of single-element RDDs by aggregating the elements in each RDD of the source DStream
		
		
		JavaDStream<String> jsonStr = dstream.reduce((x,y) -> x+y);				
	
		JavaPairDStream<String, String> pair = jsonStr.flatMapToPair(r -> {
			List<Tuple2<String, String>> pairs = new LinkedList<>();	
			
			if(r.toString().substring(r.toString().length()-1).equals("]") && r.toString().substring(0,1).equals("[")){
				
				JSONArray js1 = new JSONArray(r);
				

				for (int i = 0; i < js1.length(); i++) {
					String typeStr = js1.getJSONObject(i).get("type").toString();			
					String dateStr = js1.getJSONObject(i).get("datetime").toString();
					pairs.add(new Tuple2<String, String>(dateStr.substring(0,10),typeStr));
					
					Record record = new Record();
					record.setRecorddt(dateStr);
					record.setRecordtype(typeStr);			
					records.add(record);			
				  
				}
			}
			return pairs.iterator();
		});
				
		
		pair.dstream().saveAsTextFiles(args[1]+"/", "project");		
				
		ssc.start();//start computation
	
	    ssc.awaitTerminationOrTimeout(12000);//wait for the computation to terminate
	    Thread.sleep(3000);
	    ssc.stop(true, true);
		
		//System.out.println("count:::::::::::::::;" + records.size());
		
		if(records.size()>0){
			// warehouseLocation points to the default location for managed databases and tables
			String warehouseLocation = new File("spark-warehouse").getAbsolutePath();
		 SparkSession spark = SparkSession
				  .builder()
				  .appName("Java Spark Hive Example")
				  .config("spark.sql.warehouse.dir", warehouseLocation)
				  .config("hive.metastore.warehouse.dir",warehouseLocation)
				  .enableHiveSupport()
				  .master("local[*]")
				  .getOrCreate();
		 
				spark.sql("CREATE TABLE IF NOT EXISTS records(recorddt STRING, recordtype STRING)");
			    //for functional transformation
				Dataset<Row> recordsDF = spark.createDataFrame(records, Record.class);
			    
			  	recordsDF.write().mode(SaveMode.Append).insertInto("records");
			  	
				
				Dataset<Row> filter1 = spark.sql("select recordtype, to_date(recorddt) as rdate, COUNT(recordtype) "
						+ "AS countD from records GROUP BY to_date(recorddt), recordtype ORDER BY countD DESC LIMIT 10");
				filter1.show();
		}
		
	 
	}
}
