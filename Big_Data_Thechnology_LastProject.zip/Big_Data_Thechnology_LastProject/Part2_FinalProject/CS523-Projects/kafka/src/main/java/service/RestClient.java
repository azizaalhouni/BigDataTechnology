package service;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kafka.StreamingKafkaProducer;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFlatMapFunction;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.api.java.function.VoidFunction2;
import org.apache.spark.streaming.Duration;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.Time;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

//import com.fasterxml.jackson.databind.ObjectMapper;
import org.codehaus.jackson.map.ObjectMapper;

import scala.Tuple2;

public class RestClient {
	
	private StreamingKafkaProducer streamingProducer;
	
	public void getData() {
		
		streamingProducer = new StreamingKafkaProducer();
		
		SparkConf sparkConf = new SparkConf().setAppName("kafka").setMaster("local[*]");
		//JavaSparkContext sc = new JavaSparkContext(sparkConf);
		System.out.println("===================test2======================"); 
		
		JavaStreamingContext ssc = new JavaStreamingContext(sparkConf, Durations.seconds(3));
		System.out.println("===================test3======================");
		String url = "https://data.seattle.gov/resource/fire-911.json?$$app_token=83GHgAaXwrGXR2mx8it9JiGDw&$where=datetime>='2021-05-05'";

		System.out.println("===================test4======================");
		JavaDStream<String> dstream = ssc.receiverStream(new JavaCustomReceiver(url.trim()));
		
		System.out.println("===================test5======================");
		ObjectMapper Obj = new ObjectMapper();
		JavaDStream<String> jsonStr = dstream.reduce((x,y) -> x+y);
		System.out.println("===================test6======================");
		JavaPairDStream<String, String> pair = jsonStr.flatMapToPair(r -> {
			List<Tuple2<String, String>> pairs = new LinkedList<>();			
			JSONArray js1 = new JSONArray(r);
			
			for (int i = 0; i < js1.length(); i++) {
				String typeStr = js1.getJSONObject(i).get("type").toString();		
				String dateStr = js1.getJSONObject(i).get("datetime").toString();
				System.out.println("===================test7======================");
		        try {
		            String jsonStr2 = Obj.writeValueAsString(new Tuple2<String, String>(dateStr.substring(0,10),typeStr));
		            streamingProducer.publishMsg(jsonStr2);
		            System.out.println(jsonStr2);
		        } catch (IOException e) {
		        	System.out.println("===================test======================");
		            e.printStackTrace();
		        }
				pairs.add(new Tuple2<String, String>(dateStr.substring(0,10),typeStr));
			}
			return pairs;
		});
						
		pair.dstream().saveAsTextFiles("output/", "project");
		pair.saveAsHadoopFiles("ss", "project");
		
		ssc.start();
	    ssc.awaitTermination();
	}
	
	public static void main(String[] args) {
		RestClient rest = new RestClient();
		rest.getData();
		
	}

}
