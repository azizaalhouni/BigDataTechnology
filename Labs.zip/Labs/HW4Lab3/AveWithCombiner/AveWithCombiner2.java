package Lab3B;


	
	import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.file.FileSystem;

	import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

	public class AveWithCombiner2 extends Configured implements Tool
	{
		public static class MyWritable implements Writable {
		      
		       private IntWritable sum;
		       private IntWritable count;
		       //default constructor for de serialization
		       public MyWritable(){
		    	   //setSum(0);
		    	   sum = new IntWritable(0);
		    	   count = new IntWritable(0);
		       }
		       public MyWritable(IntWritable sum, int count){
		    	   setSum(sum);
		    	   setCount(count);
		       }
		       @Override
		       public void readFields(DataInput in) throws IOException {
			        sum.readFields(in);
			         count.readFields(in);
			       }
		       
		       public void write(DataOutput out) throws IOException {
			         sum.write(out);
			         count.write(out);
			         }
		       public int getCount(){
		    	   return count.get();
		    	   }
		       public void setCount(int count){
		       this.count = new IntWritable(count);
		       }
		       public int getSum(){
		    	return sum.get();   
		       }
		       public void setSum(IntWritable sum){
		    	this.sum = sum;   
		       }
		       
		       
		       public  MyWritable read(DataInput in) throws IOException {
		         MyWritable w = new MyWritable();
		         w.readFields(in);
		         return w;
		       }
		     }
	
		public static class WordCountMapper extends Mapper<LongWritable, Text, Text, MyWritable>
		{
			//AveWithCombiner2 a = new AveWithCombiner2();

			//private final static IntWritable one = new IntWritable(1);
			private final static IntWritable one = new IntWritable(1);
			
			
			private Text word = new Text();
			private Text temp = new Text();
			
			 private MyWritable myWritable = new MyWritable() ;

			@Override
			public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
			{
				
				
				//The key is the Year and the Temp is the value
				
				for(String token : value.toString().split("\\r?\\n"))	
				{
					
					
					//myWritable = new MyWritable();
					String words =  token.substring(15, 19);
					word.set(words);
					String tempr = token.substring(88, 92);
					
					IntWritable tem = new IntWritable(Integer.parseInt(tempr));
					
					//System.out.println(tem);
					
					try {
						myWritable.setSum(tem);
						myWritable.setCount(1);
						
					}	catch (Exception e){
						System.err.println("Date error " + e.getMessage());
					}
				
					
					
					context.write(word,myWritable);
				}
			}
		}
		public static class Combiner extends Reducer<Text, MyWritable, Text, MyWritable> {
			@Override
			public void reduce(Text key, Iterable<MyWritable> values, Context context)
			throws IOException, InterruptedException {
			int sum=0;
			int count =0;
			for (MyWritable val : values) {
			                sum += val.getSum();
			                count += val.getCount();
			                
			context.write(key,new MyWritable(new IntWritable(sum),count) ); 
			}
			}
			 
		}
		public static class WordCountReducer extends Reducer<Text, MyWritable, Text, DoubleWritable>
		{
			private DoubleWritable result = new DoubleWritable();

			@Override
			public void reduce(Text key, Iterable<MyWritable> values, Context context) throws IOException, InterruptedException
			{
				int sum = 0;
				int count = 0;
				double ave = 0.0;
				for (MyWritable val : values)
				{
					sum += val.getSum();
					count += val.getCount();
				}
				ave = (double)sum/count;
				//result.set(ave);
				context.write(key, new DoubleWritable(ave));
			}
		}
		

		public static void main(String[] args) throws Exception
		{
			Configuration conf = new Configuration();

			int res = ToolRunner.run(conf, new AveWithCombiner2(), args);

			System.exit(res);
		}

		@Override
		public int run(String[] args) throws Exception
		{
			// Delete output if exists
		   Path op = new Path(args[1]);
		    
			Job job = new Job(getConf(), "AveWithCombiner2");
			job.setJarByClass(AveWithCombiner2.class);

			job.setMapperClass(WordCountMapper.class);
			
			
			//job.setCombinerClass(WordCountReducer.class);
			job.setReducerClass(WordCountReducer.class);
			
			
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(MyWritable.class);

			job.setInputFormatClass(TextInputFormat.class);
			job.setOutputFormatClass(TextOutputFormat.class);

			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, op);
			//WRITING THIS LINE SHALL DELETE THE OUTPUT FOLDER AFTER YOU'RE DONE WITH THE //JOB
			op.getFileSystem(getConf()).delete(op,true);

			return job.waitForCompletion(true) ? 0 : 1;
		}
	}


