package Lab3;


	
	import java.io.IOException;
import java.nio.file.FileSystem;

	import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

	public class MRAverage extends Configured implements Tool
	{

		public static class WordCountMapper extends Mapper<LongWritable, Text, Text, IntWritable>
		{

			//private final static IntWritable one = new IntWritable(1);
			private final static IntWritable one = new IntWritable(1);
			
			
			private Text word = new Text();
			private Text temp = new Text();

			@Override
			public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException
			{
				//for (String token : value.toString().split("\\s+"))
				
				//The key is the Year and the Temp is the value
				
				for(String token : value.toString().split("\\r?\\n"))	
				{
					String words =  token.substring(15, 19);
					word.set(words);
					
					String tempr = token.substring(88, 92);
					
					IntWritable tem = new IntWritable(Integer.parseInt(tempr));
					
					context.write(word,tem);
				}
			}
		}

		public static class WordCountReducer extends Reducer<Text, IntWritable, Text, DoubleWritable>
		{
			//private DoubleWritable result = new IntWritable();

			@Override
			public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException
			{
				int sum = 0;
				int count = 0;
				double ave = 0.0;
				for (IntWritable val : values)
				{
					sum += (val.get()/10);
					count++;
				}
				ave = (double)sum/count;
				//result.set(ave);
				context.write(key, new DoubleWritable(ave));
			}
		}

		public static void main(String[] args) throws Exception
		{
			Configuration conf = new Configuration();

			int res = ToolRunner.run(conf, new MRAverage(), args);

			System.exit(res);
		}

		@Override
		public int run(String[] args) throws Exception
		{
			// Delete output if exists
		   Path op = new Path(args[1]);
		    
			Job job = new Job(getConf(), "WordCount");
			job.setJarByClass(MRAverage.class);

			job.setMapperClass(WordCountMapper.class);
			
			
			
			job.setReducerClass(WordCountReducer.class);
			
			
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(IntWritable.class);

			job.setInputFormatClass(TextInputFormat.class);
			job.setOutputFormatClass(TextOutputFormat.class);

			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, op);
			//WRITING THIS LINE SHALL DELETE THE OUTPUT FOLDER AFTER YOU'RE DONE WITH THE //JOB
			op.getFileSystem(getConf()).delete(op,true);

			return job.waitForCompletion(true) ? 0 : 1;
		}
	}


