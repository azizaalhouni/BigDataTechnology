package Lab3D;

	import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

	import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import Lab3D.InMapperCombinerWithComparable.MyWritableComparable;

	 


	public class OverRideComparable {
	   
	   public static class WritablePair implements Writable {
	      public int sum;
	      public int count;
	   
	      public WritablePair() {;}
	      
	      public WritablePair(int sum, int count) {
	         this.sum = sum;
	         this.count = count;
	      }

	      
	      public int getSum() {
	         return sum;
	      }

	      public void setSum(int sum) {
	         this.sum = sum;
	      }

	      public int getCount() {
	         return count;
	      }

	      public void setCount(int count) {
	         this.count = count;
	      }

	      @Override
	      public void write(DataOutput out) throws IOException {
	         out.writeInt(sum);
	         out.writeInt(count);
	      }

	      @Override
	      public void readFields(DataInput in) throws IOException {
	         sum = in.readInt();
	         count = in.readInt();
	      }

	      public static WritablePair read(DataInput in) throws IOException {
	         WritablePair wp = new WritablePair();
	         wp.readFields(in);
	         return wp;
	      }

	      @Override
	      public String toString( ) {
	         return "(" + sum + "," + count + ")";
	      } 
	      
	   }
	 //Add Comparable
	   public static class DescendingFloatComparator extends WritableComparator {
	        
	        public DescendingFloatComparator() {
	           super(FloatWritable.class, true);
	        }

	        @SuppressWarnings("rawtypes")
	        @Override
	        public int compare(WritableComparable w1, WritableComparable w2) {
	            FloatWritable key1 = (FloatWritable) w1;
	            FloatWritable key2 = (FloatWritable) w2;          
	            return -1 * key1.compareTo(key2);
	        }
	    }

  
      /*
	 		public class Comparable implements WritableComparable {
	 		       // Some data
	 		       private int counter;
	 		       private long timestamp;
	 		       Text year;
	 		       
	 		       Comparable(Text year){
	 		    	   this.year = year;
	 		       }
	 		       public void write(DataOutput out) throws IOException {
	 		         out.writeInt(counter);
	 		         out.writeLong(timestamp);
	 		       }
	 		       
	 		       public void readFields(DataInput in) throws IOException {
	 		         counter = in.readInt();
	 		         timestamp = in.readLong();
	 		       }
	 		       public Text getYear(){
	 		    	   return year;
	 		       }
	 		       
	 		       public int compareTo(Comparable o) {
	 		    	  
	 		    		        //int compareValue = this.year.compareTo(o.getYear());
	 		    		       return this.year.compareTo(o.year) * (-1);// sort descending
	 		    		      }
	 		    	   //if current object is greater than
	 		       /*
	 		    	   int decYear = this.year.compareTo(o.year);
	 		    	   if(decYear >=1 )
	 		    		   return -1;
	 		    	   else
	 		    		   if(decYear < 0){
	 		    			   return 1;
	 		    		   }
	 		    		   else
	 		    			   //if equal
	 		    		   return 0;
	 		       }
*/
	   /*
	 		       public int hashCode() {
	 		         final int prime = 31;
	 		         int result = 1;
	 		         result = prime * result + counter;
	 		         result = prime * result + (int) (timestamp ^ (timestamp >>> 32));
	 		         return result;
	 		       }
	 		     */
	 		 
	   public static void main(String[] args) throws Exception {
	      Configuration config = new Configuration();
	      String[] files = new GenericOptionsParser(config, args)
	            .getRemainingArgs();
	      Path input = new Path(files[0]);
	      Path output = new Path(files[1]);

	      @SuppressWarnings("deprecation")
	      Job job = new Job(config, "in-mapper-average");

	      job.setJarByClass(OverRideComparable.class);

	      // Mapper Output
	      job.setMapOutputKeyClass(Text.class);
	      job.setMapOutputValueClass(WritablePair.class);

	      // Reducer Output
	      job.setOutputKeyClass(Text.class);
	      job.setOutputValueClass(DoubleWritable.class);

	      job.setMapperClass(Map.class);
	      job.setSortComparatorClass(DescendingFloatComparator.class);
	      job.setReducerClass(Reduce.class);

	      FileInputFormat.addInputPath(job, input);
	      FileOutputFormat.setOutputPath(job, output);
	      	output.getFileSystem(config).delete(output, true);
	      System.exit(job.waitForCompletion(true) ? 0 : 1);

	   }

	   public static class Map extends
	         Mapper<LongWritable, Text, Text, WritablePair> {

	      private HashMap<Text, WritablePair> H;

	      protected void setup(Context context) throws IOException,
	            InterruptedException {
	         Configuration conf = context.getConfiguration();
	         H = new HashMap<Text, WritablePair>();
	      }

	      public void map(LongWritable key, Text value, Context con)
	            throws IOException, InterruptedException {
	    	  for(String token : value.toString().split("\\r?\\n"))	
				{
					String words =  token.substring(15, 19);
					int tempr = Integer.parseInt(token.substring(88, 92));
					tempr = tempr/10;
					Text IP = new Text(words);
	            if (H.containsKey(IP)) {
	               H.put(IP, new WritablePair(H.get(IP).getSum() + tempr, H
	                     .get(IP).getCount() + 1));
	            } else {
	               H.put(IP, new WritablePair(tempr, 1));
	            }
	         }

	      }

	      @Override
	      public void cleanup(Context context) throws IOException,
	            InterruptedException {
	         for (Text key : H.keySet()) {
	        	// Comparable year = new Comparable(key);
	        	// MyWritableComparable key1 = new MyWritableComparable(key);
	        	//key.compareTo(key1);
	            context.write(key, H.get(key)); // Final Mapper Output
	         }
	      }

	   }

	   public static class Reduce extends
	         Reducer<Text, WritablePair, Text, DoubleWritable> { // Reducer Input
	                                                // , Reducer
	                                                // Output Format
	      public void reduce(Text key, Iterable<WritablePair> values,
	            Context context) throws IOException, InterruptedException {
	         int sum = 0;
	         int cnt = 0;

	         for (WritablePair val : values) {
	            sum += val.getSum();
	            cnt += val.getCount();
	         }
	         double avg = (double)sum / cnt;
	         context.write(key, new DoubleWritable(avg));
	      }

	   }

	}


