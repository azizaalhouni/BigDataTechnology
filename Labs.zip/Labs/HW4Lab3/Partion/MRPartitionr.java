package Lab3E;



	import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

	import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

	 


	public class MRPartitionr {
	   
	   public static class WritablePair implements Writable {
	      public int sum;
	      public int count;
	   
	      public WritablePair() {;}
	      
	      public WritablePair(int sum, int count) {
	         this.sum = sum;
	         this.count = count;
	      }

	      
	      public int getSum() {
	         return sum;
	      }

	      public void setSum(int sum) {
	         this.sum = sum;
	      }

	      public int getCount() {
	         return count;
	      }

	      public void setCount(int count) {
	         this.count = count;
	      }

	      @Override
	      public void write(DataOutput out) throws IOException {
	         out.writeInt(sum);
	         out.writeInt(count);
	      }

	      @Override
	      public void readFields(DataInput in) throws IOException {
	         sum = in.readInt();
	         count = in.readInt();
	      }

	      public static WritablePair read(DataInput in) throws IOException {
	         WritablePair wp = new WritablePair();
	         wp.readFields(in);
	         return wp;
	      }

	      @Override
	      public String toString( ) {
	         return "(" + sum + "," + count + ")";
	      } 
	      
	   }
	   
	   public class HashPartitioner extends Partitioner<Text, IntWritable>   {
		
	   public int getPartition(Text key, IntWritable value, int numReduceTasks) {
		   
		   int partitionKey = Integer.parseInt(key.toString());
		   if(numReduceTasks == 0)   return 0;
		   else
		   
           if(partitionKey < 1930 )
               return 0;
           else 
               return 1;
	     
	   }
	   }
	   public static void main(String[] args) throws Exception {
	      Configuration config = new Configuration();
	      String[] files = new GenericOptionsParser(config, args)
	            .getRemainingArgs();
	      Path input = new Path(files[0]);
	      Path output = new Path(files[1]);
	      
	      @SuppressWarnings("deprecation")
	      Job job = new Job(config, "in-mapper-average");

	      job.setJarByClass(MRPartitionr.class);

	      // Mapper Output
	      job.setMapOutputKeyClass(Text.class);
	      job.setMapOutputValueClass(WritablePair.class);

	      
	      // Reducer Output
	      job.setOutputKeyClass(Text.class);
	      job.setOutputValueClass(DoubleWritable.class);

	      job.setMapperClass(Map.class);
	     
	      job.setPartitionerClass(HashPartitioner.class);
	   
	      job.setReducerClass(Reduce.class);
	      job.setNumReduceTasks(2);
	      

	      FileInputFormat.addInputPath(job, input);
	      FileOutputFormat.setOutputPath(job, output);
	      output.getFileSystem(config).delete(output,true);
	      
	      System.exit(job.waitForCompletion(true) ? 0 : 1);

	   }

	   public static class Map extends
	         Mapper<LongWritable, Text, Text, WritablePair> {

	      private HashMap<Text, WritablePair> H;

	      protected void setup(Context context) throws IOException,
	            InterruptedException {
	         Configuration conf = context.getConfiguration();
	         H = new HashMap<Text, WritablePair>();
	      }

	      public void map(LongWritable key, Text value, Context con)
	            throws IOException, InterruptedException {
	    	  for(String token : value.toString().split("\\r?\\n"))	
				{
					String words =  token.substring(15, 19);
					int tempr = Integer.parseInt(token.substring(88, 91));
					Text IP = new Text(words);
	            if (H.containsKey(IP)) {
	               H.put(IP, new WritablePair(H.get(IP).getSum() + tempr, H
	                     .get(IP).getCount() + 1));
	            } else {
	               H.put(IP, new WritablePair(tempr, 1));
	            }
	         }

	      }

	      @Override
	      public void cleanup(Context context) throws IOException,
	            InterruptedException {
	         for (Text key : H.keySet()) {
	            context.write(key, H.get(key)); // Final Mapper Output
	         }
	      }

	   }

	   public static class Reduce extends
	         Reducer<Text, WritablePair, Text, DoubleWritable> { // Reducer Input
	                                                // , Reducer
	                                                // Output Format
	      public void reduce(Text key, Iterable<WritablePair> values,
	            Context context) throws IOException, InterruptedException {
	         int sum = 0;
	         int cnt = 0;

	         for (WritablePair val : values) {
	            sum += val.getSum();
	            cnt += val.getCount();
	         }
	         double avg = (double)sum / cnt;
	         context.write(key, new DoubleWritable(avg));
	      }

	   }

	}



