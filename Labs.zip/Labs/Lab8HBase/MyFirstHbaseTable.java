package hbaseTest;


	import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;

//import org.apache.hadoop.fs.shell.CopyCommands.Put;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.io.compress.Compression.Algorithm;
import org.apache.hadoop.hbase.thrift2.generated.THBaseService.AsyncProcessor.put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.client.Put;

import com.amazonaws.services.dynamodbv2.document.Table;

//import com.amazonaws.thirdparty.ion.impl.UnifiedDataPageX.Bytes;

	public class MyFirstHbaseTable
	{

		private static final String TABLE_NAME = "user";
		private static final String CF_DEFAULT = "personal";//col family name

		@SuppressWarnings("deprecation")
		public static void main(String... args) throws IOException
		{

			Configuration config = HBaseConfiguration.create();
			 
			
				// Instantiating configuration class
			    

			      // Instantiating HbaseAdmin class
			      HBaseAdmin admin = new HBaseAdmin(config);

			      // Instantiating table descriptor class
			      HTableDescriptor tableDescriptor = new HTableDescriptor(TableName.valueOf(TABLE_NAME));

			      // Adding column families to table descriptor
			      tableDescriptor.addFamily(new HColumnDescriptor("personal"));
			      tableDescriptor.addFamily(new HColumnDescriptor("professional"));

			      // Execute the table through admin
			      admin.createTable(tableDescriptor);
			      System.out.println(" Table created ");
			      HTable hTable = new HTable(config, "user");
				Put p = new Put(Bytes.toBytes(1));
				 p.add(Bytes.toBytes(CF_DEFAULT),Bytes.toBytes("Name"),Bytes.toBytes("John"));
				 p.add(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("city"),Bytes.toBytes("Boston"));
				 p.add(Bytes.toBytes("professional"), Bytes.toBytes("Designation"),Bytes.toBytes("Manager"));
				 p.add(Bytes.toBytes("professional"), Bytes.toBytes("salary"),Bytes.toBytes("150,000"));
				 
				hTable.put(p);
				 p = new Put(Bytes.toBytes(2));
				 p.add(Bytes.toBytes(CF_DEFAULT),Bytes.toBytes("Name"),Bytes.toBytes("Mary"));
				 p.add(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("city"),Bytes.toBytes("New York"));
				 p.add(Bytes.toBytes("professional"), Bytes.toBytes("Designation"),Bytes.toBytes("Sr.Engineer"));
				 p.add(Bytes.toBytes("professional"), Bytes.toBytes("salary"),Bytes.toBytes("130,000"));
				 hTable.put(p);
				 p = new Put(Bytes.toBytes(3));
				 p.add(Bytes.toBytes(CF_DEFAULT),Bytes.toBytes("Name"),Bytes.toBytes("Bob"));
				 p.add(Bytes.toBytes(CF_DEFAULT), Bytes.toBytes("city"),Bytes.toBytes("Fremont"));
				 p.add(Bytes.toBytes("professional"), Bytes.toBytes("Designation"),Bytes.toBytes("Jr.Engineer"));
				 p.add(Bytes.toBytes("professional"), Bytes.toBytes("salary"),Bytes.toBytes("90,000"));
				 hTable.put(p);
				
				
				System.out.println("data inserted");
				
				System.out.print("Creating table.... ");
				
				Get get = new Get(Bytes.toBytes("row3"));
				get.addFamily(Bytes.toBytes("professional"));
				
				/*
				if (admin.tableExists(tableDescriptor.getTableName()))
				{
					admin.disableTable(tableDescriptor.getTableName());
					admin.deleteTable(tableDescriptor.getTableName());
				}
				//create table
			admin.createTable(tableDescriptor);*/
				hTable.close();
				System.out.println(" Done!");
			}
		}
	


