package hbaseTest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;

//import org.apache.hadoop.fs.shell.CopyCommands.Put;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.io.compress.Compression.Algorithm;
import org.apache.hadoop.hbase.thrift2.generated.THBaseService.AsyncProcessor.put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.hbase.client.Put;

import com.amazonaws.services.dynamodbv2.document.Table;
public class UpdateData {
	public static void main(String[] args) throws IOException {

	      // Instantiating Configuration class
	      Configuration config = HBaseConfiguration.create();

	      // Instantiating HTable class
	      HTable hTable = new HTable(config, "user");

	      // Instantiating Put class
	      //accepts a row name
	      Put p = new Put(Bytes.toBytes(3));

	      // Updating a cell value
	      p.add(Bytes.toBytes("professional"),
	      Bytes.toBytes("Designation"),Bytes.toBytes("Sr.Engineer"));
	      p.add(Bytes.toBytes("professional"),
	    	      Bytes.toBytes("salary"),Bytes.toBytes("94,500"));

	      // Saving the put Instance to the HTable.
	      hTable.put(p);
	      System.out.println("data Updated");

	      // closing HTable
	      hTable.close();
	   }

}
