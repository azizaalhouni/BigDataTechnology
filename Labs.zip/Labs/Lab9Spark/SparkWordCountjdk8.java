package cs523.SparkWC;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Scanner;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Enumeration.Val;
import scala.Tuple2;

public class SparkWordCountjdk8
{

	public static void main(String[] args) throws Exception
	{/*
		// Create a Java Spark Context
		JavaSparkContext sc = new JavaSparkContext(new SparkConf().setAppName("wordCount").setMaster("local"));

		// Load our input data
		JavaRDD<String> lines = sc.textFile(args[0]);

		// Calculate word count
		JavaPairRDD<String, Integer> counts = lines
					.flatMap(line -> Arrays.asList(line.split(" ")))
					.mapToPair(w -> new Tuple2<String, Integer>(w, 1))
					.reduceByKey((x, y) -> x + y);

		// Save the word count back out to a text file, causing evaluation
		counts.saveAsTextFile(args[1]);
		*/
		JavaSparkContext sc = new JavaSparkContext(new SparkConf().setAppName("wordCount").setMaster("local"));
		//B Read an input set of text documents
		JavaRDD<String> lines = sc.textFile(args[0]);
		//A Get a word frequency threshold from user
		System.out.println("Please insert input");
		Scanner scanner = new java.util.Scanner(System.in);
		int input = scanner.nextInt();
		
		
		//C  Calculate word count
				JavaPairRDD<String, Integer> counts = lines
							.flatMap(line -> Arrays.asList(line.split(" ")))
							.mapToPair(w -> new Tuple2<String, Integer>(w, 1))
							.reduceByKey((x, y) -> x + y);
				//D
				JavaPairRDD<String, Integer> filterCount = counts.filter(s-> s._2>input);
				
				//E
				//val charCounts = filterCount.flatMap(_._1.toCharArray).map((_, 1)).reduceByKey(_ + _);
				//Val split = filterCount.flatMap(line->line._1.split(""));
				//split.comment();
				//Val litterCount =  filterCount.flatMap(_._1.toCharArray).map((_,_1)).reduceByKey(_+_);
				
				JavaPairRDD<Character, Integer> charCounts = filterCount.flatMap(
		                s -> {
		                    Collection<Character> chars = new ArrayList<>(s._1().length());
		                    for (char c : s._1().toCharArray()) {
		                        chars.add(c);
		                    }
		                    return chars;
		                }
		        ).mapToPair(c -> new Tuple2<>(c, 1))
		                .reduceByKey((i1, i2) -> i1 + i2);

		        System.out.println(charCounts.collect());
		        sc.close();
		        //charCounts.saveAsTextFile(args[1]);
		    }
				
		
	
		
		

		
	}

